﻿using System;
using System.Collections.Generic;

namespace Prep.Models
{
    public class Recipe
    {
        public int RecipeID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Rating { get; set; }
        public string Creator { get; set; }
        public DateTime Datepicked { get; set; }
        public ICollection<UserPlan> UserMealPlans { get; set; }
    }
}
