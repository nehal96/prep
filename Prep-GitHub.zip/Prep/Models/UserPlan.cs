﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Prep.Models
{
    public class UserPlan
    {
        public int UserPlanID { get; set; }
        public int RecipeID { get; set; }
        public int UserID { get; set; }
        public DateTime PlanDate { get; set; }

        public  Recipe Recipe  { get; set; }
        public User User { get; set; }

    }
}
