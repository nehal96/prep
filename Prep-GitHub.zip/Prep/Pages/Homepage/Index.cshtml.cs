﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prep.Data;
using Prep.Models;

namespace Prep.Pages.Homepage
{
    public class IndexModel : PageModel
    {
        private readonly Prep.Data.ApplicationDbContext _context;

        public IndexModel(Prep.Data.ApplicationDbContext context)
        {
            _context = context;
        }
        public string NameSort { get; set; }
        public string DateSort { get; set; }
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }


        public IList<Recipe> Recipe { get;set; }

        public async Task OnGetAsync(string sortOrder, string searchString)
        {
            NameSort = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            DateSort = sortOrder == "Date" ? "date_desc" : "Date";
            CurrentFilter = searchString;

            IQueryable<Recipe> recipeIQ = from s in _context.Recipe
                                            select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                recipeIQ = recipeIQ.Where(s => s.Name.Contains(searchString)
                                       || s.Creator.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    recipeIQ = recipeIQ.OrderByDescending(s => s.Name);
                    break;
                case "Date":
                    recipeIQ = recipeIQ.OrderBy(s => s.Datepicked);
                    break;
                case "date_desc":
                    recipeIQ = recipeIQ.OrderByDescending(s => s.Datepicked);
                    break;
                default:
                    recipeIQ = recipeIQ.OrderBy(s => s.Name);
                    break;
            }

            Recipe = await recipeIQ.AsNoTracking().ToListAsync();
        }

    }
}
