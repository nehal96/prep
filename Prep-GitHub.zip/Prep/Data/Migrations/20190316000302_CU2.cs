﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Prep.Data.Migrations
{
    public partial class CU2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Creator",
                table: "Recipe",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Creator",
                table: "Recipe");
        }
    }
}
