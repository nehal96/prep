﻿using Prep.Models;
using System;
using System.Linq;

namespace Prep.Models
{
    public static class DbInitializer
    {
        public static void Initialize(Data.ApplicationDbContext context)
        {
            // context.Database.EnsureCreated();

            // Look for any recipes.
            if (context.Recipe.Any())
            {
                return;   // DB has been seeded
            }

            var recipes = new Recipe[]
            {
            new Recipe{Name="Butter Chicken",Description="Easy to cook, creamy butter chicken",Rating="5 Stars",Creator="Jeffrey Salvo",Datepicked=DateTime.Parse("2016-09-01")},
            new Recipe{Name="Fish Tacos",Description="Tasty, Zesty fish tacos",Rating="4 Stars",Creator="Nick Kong",Datepicked=DateTime.Parse("2017-09-01")},
            new Recipe{Name="Crispy Breaded Chicken",Description="Crispy Breaded chicken in 5 minutes",Rating="3 Stars",Creator="Charles Ma",Datepicked=DateTime.Parse("2018-09-01")},
            };
            foreach (Recipe s in recipes)
            {
                context.Recipe.Add(s);
            }
            context.SaveChanges();

            var users = new User[]
            {
            new User{UserID=005,Email="Chemistry",FirstName="Jeffrey",LastName="Salvo",DOB="1996-08-19",Address="2984 Creststone street",CreationDate=DateTime.Parse("2018--01")}
            };
            foreach (User c in users)
            {
                context.User.Add(c);
            }
            context.SaveChanges();

            var userplans = new UserPlan[]
            {
            new UserPlan{RecipeID=1,UserID=005,PlanDate=DateTime.Parse("2018-10-01")},
            };
            foreach (UserPlan e in userplans)
            {
                context.UserPlan.Add(e);
            }
            context.SaveChanges();
        }
    }
}
